"""[summary]
Controller for <Mongo & SQL>
"""

from .manager import Mongo, Sql
from .manager.utils import Objects
