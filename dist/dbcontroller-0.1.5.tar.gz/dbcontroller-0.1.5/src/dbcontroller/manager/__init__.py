"""[summary]
Mongo & SQL - Object-Manager
"""

from .mongo import mongo as Mongo
from .sql import sql as Sql
